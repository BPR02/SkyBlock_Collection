Interact:	[![Static Badge](https://img.shields.io/badge/_-Discord-black?logo=discord&logoColor=%235865F2&labelColor=black&color=%235865F2)](https://discord.gg/mzWSZuGatd)
[![Github Badge](https://img.shields.io/badge/_-GitHub-black?logo=github&logoColor=white&labelColor=%23181717&color=white&)](https://github.com/BPR02/SkyBlock_Collection)  
Download: [![Smithed Badge](https://img.shields.io/badge/_-Smithed-black?logo=hackthebox&logoColor=%231b48c4&labelColor=black&color=%231b48c4)](https://smithed.net/packs/skyvoid_additions)
[![Modrinth Badge](https://img.shields.io/badge/_-Modrinth-black?logo=modrinth&logoColor=%2300AF5C&labelColor=black&color=%2300AF5C)](https://modrinth.com/datapack/sky-void-additions)  
Support: [![BMC Badge](https://img.shields.io/badge/_%20-Buy%20Me%20a%20Coffee-black?logo=buymeacoffee&logoColor=%23FFDD00&labelColor=black&color=%23FFDD00)](https://bmc.link/bpr02)
[![BisectHosting Badge](https://img.shields.io/badge/Rent%20a%20Server-black?logo=bisecthosting&logoColor=%2306ddff&labelColor=%23030525&color=%2337e3f3)](https://www.bisecthosting.com/skyvoid)
# Sky Void Additions
This data pack adds vanilla-like mechanics to the game which makes all items, mobs, and advancements obtainable in SkyBlock. Some mechanics require structure bounding boxes, so make sure your SkyBlock map or data pack generates those bounding boxes, such as [Standard SkyBlock](https://smithed.dev/packs/standard-skyblock).

Every setting is toggleable via an in-game menu. Using the following command will allow users to modify the settings: `/function skyvoid_additions:customize/update_config/open_menu`. Below is a list of all mechanics.

## Mechanics
The following settings are enabled by default

### Amethyst Geode Creation
Geodes can be created with packed ice and lava. Surrounding a 2x2x2 cube of packed ice with lava will start the conversion. The four lava on top of the packed ice cube must be source blocks, and the rest can be flowing as long as every exposed side of the packed ice is touching lava.

### Armor Chipping
Hitting a mob wearing a chestplate can break the chestplate and drop one or two base material (e.g. diamond, netherite ingot, iron ingot)

### Armor Trim Gifts
Armorers will gift armor trims based on the biome or structure they are in

### Bastion Loot from Suspicious Gravel
Sniffers placing suspicious gravel in a bastion remnant can contain bastion loot.  
**Requires Sneezy Suspicious Sniffers*

### Cave Spiders Spawn in Cobwebs
Some spiders spawned inside cobwebs (3x3) at light level 0 will spawn as cave spiders

### Endermites Propogate Chorus
Endermites can dig into end stone and convert it into a chorus flower. The end stone dug into must have another end stone block below.

### Cocoa Bean Fishing
Cocoa beans can be fished as junk in jungles

### Coral Block Growth
Bonemealing coral blocks will convert attached coral fans into blocks

### Dead Bush Fishing
Dead bushes can be fished as junk in deserts and badlands

### Echo Shards from Amethyst
Amethyst clusters placed on a sculk catalyst will drop as echo shards when a player kills a mob nearby

### Elder Guardian from Lightning
Guardians struck by lightning will convert into elder guardians

### Cats Gift Enchanted Golden Apples
Tamed cats will gift enchanted golden apples while sleeping

### Endermites Convert Cobblestone to End Stone
Endermites can dig into cobblestone to convert it to end stone

### Glow Lichen Fishing
Glow lichen can be fished as junk in lush caves

### Gold Block Bartering
Piglins will barter pigstep, horse armor, gilded blackstone, nether wart, and banner patterns for gold blocks

### Elder Guardians Drop Heart of the Sea
Elder Guardians can drop a heart of the sea

### Piglin Brutes Wear Netherite Armor
Piglin brutes can spawn in bastion remnants wearing netherite armor

### Piglins Hold Netherite Upgrade Template
Piglins can spawn in bastion remnants holding a netherite upgrade template

### Netherrack Portals
Netherrack platforms will generate instead of obsidian when spawning over the void

### Nylium Portals
Nylium platforms will generate instead of obsidian when spawning over the void in crimson and warped forests  
**Requires Netherrack Portals*

### Magma Cube Ore Conversions
Magma cubes will engulf stone, deepslate, and netherrack and convert them into ores or different stone types

### Burnt Husks Create Sand
Husks that die on fire will convert dirt into sand below them, and coarse dirt into red sand

### Silverfish from Lightning  
Stone, cobblestone, and deepslate struck by nearby lightning will become infested with silverfish

### Shear Big Dripleaves
Mining the top big dripleaf with shears can drop small dripleaves

### Drowneds Hatch Sniffer Eggs
Drowneds can spawn holding a sniffer egg which they will place after trampling turtle eggs

### Moss Grow Spore Blossoms
Moss bonemealed in lush caves can grow a spore blossom beneath it

### Sneezy Suspicious Sniffers
Sniffers sneeze when on sand and gravel, which can convert them into suspicious variants

### Foxes Spawn with Sweet Berries
Foxes can spawn with sweet berries

### Swift Sneak Gifts
Librarians gift swift sneak if in an ancient city

### Additional Wandering Trades
Otherside, relic, disc fragment 5, double tall flowers, glow berries, bushes, and resin clumps can be bought

### Traders with Camels
Some wandering traders will have a camel on a leash instead of trader llamas

### Breeze Conversion
Blazes killed by powdered snow will convert into a breeze

### Trial Chamber Sherd Gifts
Masons in trial chambers will gift pottery sherds exclusive to trial chambers

### Trial Spawners from Sculk
Players in trial chambers with Bad Omen V can convert shriekers into trial spawners by killing mobs on shriekers above a catalyst

### Vaults from Ominous Raid Captains
Raid Captains in a level 5 raid can replace bells with vaults within a trial chamber bounding box

### More Discs from Vaults
Ominous vaults can reward creator music box

### Calcite from Dead Coral Blocks
Dead coral blocks can be converted into calcite by placing them next to lava. The more lava around the block, the quicker it will convert (capped at 4 lava blocks, at least one of the lava block need to be a source block, the other can be flowing)

### Magma Blocks Cool into Tuff
A magma block hit by a wind charge will convert into tuff

### Gravel Crushes into Sand
Anvil falling on gravel will convert it into sand

### Tuff Packs into Deepslate
Anvil falling on tuff will convert it into deepslate

### Armored Zombie Nautilus Jockeys
Zombie nautilus jockeys can spawn equipped with nautlius armor


## Extra Mechanics
The following settings are disabled by default

### Spiders Generate Cobwebs
*cobwebs are obtainable with the weaving effect*  
Spiders in ceiling edges will generate cobwebs

### Vexes Convert to Allays
*in Standard SkyBlock, mansions and pillager towers generate with allays, but no blocks*  
Vexes will play a note block above them and will listen for a matching note played by a player (no redstone). After 5 matching notes, it will convert into an allay.

### Coal Compresses into Diamonds
*armor chipping is the default way to get diamonds (apart from end city ships)*  
Anvils dropped on a stack of coal blocks will compress them into diamonds

### Dragon Egg Drop
*disabled since it's the same as vanilla: there's only ever one egg, which is already obtainable*  
Upon player kill, the dragon has a rare chance to drop a dragon egg

### Dragon Elytra Drop
*in Standard SkyBlock, end city ships generate*  
Upon player kill, the dragon has a rare chance to drop a broken elytra

### Dragon Head from Charged Creeper
*in Standard SkyBlock, end city ships generate*  
Upon charged creeper kill, the dragon will drop its head

### Wandering Traders Sell Enchanted Golden Apples
*cat gifts are the default way to get enchanted golden apples*  
Enchanted golden apples can be bought for 6 emeralds  
**Requires Additional Wandering Trades*

### Elytra from End Phantoms
*in Standard SkyBlock, end city ships generate*  
Large phantoms will spawn above players in the end barrens. Upon death, they have a chance to drop a broken elytra

### Wandering Traders Sell Grass Blocks
*in Standard SkyBlock, grass is generated with the main island*  
Grass blocks can be bought for 3 emeralds  
**Requires Additional Wandering Trades*

### Heart of the Sea Fishing
*elder guardians are the default way to get hearts of the sea*  
Hearts of the sea can be fished as treasure

### Wandering Traders Sell Lava Buckets
*in Standard SkyBlock, lava is in the starter chest*  
Lava can be bought for 5 emeralds  
**Requires Additional Wandering Trades*

###  Lava Bucket Gifts
*in Standard SkyBlock, lava is in the starter chest*  
Toolsmiths will gift lava buckets

### Nether Wart Bartering
*gold block bartering is the default way to get nether wart*  
Piglins will barter nether wart for gold ingots

### Netherrack Bartering
*gold block bartering is the default way to get netherrack*  
Piglins will barter netherrack from gold ingots

### Nylium Bartering
*nylium portals are the default way to get nylium (apart from the main nether island)*  
Piglins will barter nylium from gold ingots

### Sonic Boom End Portal
*in Standard SkyBlock, end portals generate*  
Endermen killed by a warden's sonic boom can drop end portal frames

### Pottery Sherd Gifts
*sneezy suspicious sniffers are the default way to get pottery sherds*  
Masons will gift pottery sherds based on the biome

### Husks Drop Sand
*burning husks on dirt is the default way to get sand and red sand*  
Husks can drop sand and red sand

### Sand Packs into Sandstone
Anvil falling on sand will convert it into sandstone

### Mason Trade Sandstone
Mason leveling up to Journeyman level have a chance to sell sandstone and red sandstone

### Shrieker Endermen Spawn
*in Standard SkyBlock sculk shriekers generate*  
Endermen can spawn on deepslate tiles holding sculk shriekers that can spawn wardens when placed by the enderman

### Shulkers from Lightning
*in Standard SkyBlock end cities generate with skulkers, but no blocks*  
Lightning hitting a lightning rod attached to a purpur block will convert it into a shulker

### Wandering Traders Sell Sniffer Eggs
*drowneds hatching sniffer eggs is the default way to get sniffers*  
Sniffer eggs can be bought for 6 emeralds  
**Requires Additional Wandering Trades*

### Wandering Traders Sell Sweet Berries
*fox spawning is the default way to get sweet berries*  
Sweet berries can be bought for 1 emerald  
**Requires Additional Wandering Trades*

### Trial Chamber Sherds from Traders
Wandering traders will sell pottery sherds exclusive to trial chambers  
**Requires Additional Wandering Trades*

### Heavy Core Renewability
Falling anvils shot by a breeze have a chance to convert into a heavy core

### Ominous Keys from Ominous Raid Captains
Raid Captains in a level 5 raid can drop ominous trial keys
