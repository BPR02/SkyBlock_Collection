tag @s add skyvoid_enderman_check
execute at @s if predicate skyvoid_additions:shriekers_from_enderman/shrieker_chance run data modify entity @s carriedBlockState set value {Name: "sculk_shrieker", Properties: {can_summon: "true"}}
