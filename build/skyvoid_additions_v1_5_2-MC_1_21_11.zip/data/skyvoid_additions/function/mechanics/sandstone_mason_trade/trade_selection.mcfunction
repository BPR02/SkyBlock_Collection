execute as @s if score @s trade_choice_1 matches 8 run data modify entity @s Offers.Recipes[4] set value {buy: {id: "minecraft:emerald", count: 1}, sell: {id: "minecraft:sandstone", count: 4}, maxUses: 16, rewardExp: 1, xp: 10, priceMultiplier: 0.05f}
execute as @s if score @s trade_choice_1 matches 9 run data modify entity @s Offers.Recipes[4] set value {buy: {id: "minecraft:emerald", count: 1}, sell: {id: "minecraft:red_sandstone", count: 4}, maxUses: 16, rewardExp: 1, xp: 10, priceMultiplier: 0.05f}
execute as @s if score @s trade_choice_2 matches 8 run data modify entity @s Offers.Recipes[5] set value {buy: {id: "minecraft:emerald", count: 1}, sell: {id: "minecraft:sandstone", count: 4}, maxUses: 16, rewardExp: 1, xp: 10, priceMultiplier: 0.05f}
execute as @s if score @s trade_choice_2 matches 9 run data modify entity @s Offers.Recipes[5] set value {buy: {id: "minecraft:emerald", count: 1}, sell: {id: "minecraft:red_sandstone", count: 4}, maxUses: 16, rewardExp: 1, xp: 10, priceMultiplier: 0.05f}
execute as @s run tag @s add trade_changed
scoreboard objectives remove trade_choice_1
scoreboard objectives remove trade_choice_2
