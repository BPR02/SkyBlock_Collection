advancement revoke @s only skyvoid_additions:netherrack_portals/enter_nether
execute store result score $air_count skyvoid_additions run clone ~-3 ~-2 ~-3 ~3 ~4 ~3 ~-3 ~-2 ~-3 filtered air force
execute if score $air_count skyvoid_additions matches 319 run function skyvoid_additions:mechanics/netherrack_portals/check_structure
