item replace entity @s armor.chest with air
particle item{item: "netherite_chestplate"} ~ ~0.8 ~ 0.2 0.2 0.2 0.1 5
playsound minecraft:item.shield.break neutral @a ~ ~ ~ 1 1
loot spawn ~ ~0.8 ~ loot skyvoid_additions:gameplay/armor_chipping/netherite
