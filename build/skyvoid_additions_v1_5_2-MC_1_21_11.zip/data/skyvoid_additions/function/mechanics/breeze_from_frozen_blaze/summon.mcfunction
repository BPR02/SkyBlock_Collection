summon breeze
playsound minecraft:entity.breeze.charge hostile @a[distance=..16] ~ ~ ~ 1 0.7
particle minecraft:snowflake ~ ~0.5 ~ 0 0.5 0 0.05 15
kill @s
