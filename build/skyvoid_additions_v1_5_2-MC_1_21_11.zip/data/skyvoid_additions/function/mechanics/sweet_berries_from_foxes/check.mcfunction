tag @s add skyvoid_fox_check
execute at @s if predicate skyvoid_additions:sweet_berries_from_foxes/sweet_berry_chance run item replace entity @s weapon.mainhand with minecraft:sweet_berries
