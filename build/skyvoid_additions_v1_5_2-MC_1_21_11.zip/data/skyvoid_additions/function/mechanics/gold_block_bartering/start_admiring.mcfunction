tag @s add skyvoid_gold_block_piglin
execute store result score @s skyvoid_waiting run data get entity @s Brain.memories."minecraft:admiring_item".ttl
schedule function skyvoid_additions:mechanics/gold_block_bartering/check_time 1 append
