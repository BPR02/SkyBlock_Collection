summon elder_guardian ~ ~ ~
tp @e[type=elder_guardian, distance=0, limit=1] @s
data merge entity @s {Health: 0.0f, DeathLootTable: "minecraft:empty", DeathTime: 18s}
tp @s ~ -2050 ~
