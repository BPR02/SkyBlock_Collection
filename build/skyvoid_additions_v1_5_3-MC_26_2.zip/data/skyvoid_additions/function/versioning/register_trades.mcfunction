execute if score skyvoid_additions load.status matches 1 if score trader_additions skyvoid_config matches 1 run function skyvoid_additions:mechanics/trader_additions/register_trades
