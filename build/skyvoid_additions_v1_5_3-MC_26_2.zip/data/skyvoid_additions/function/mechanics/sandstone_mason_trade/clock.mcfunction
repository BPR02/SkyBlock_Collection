schedule function skyvoid_additions:mechanics/sandstone_mason_trade/clock 1
execute as @e[type=minecraft:villager, nbt={VillagerData: {profession: "minecraft:mason", level: 3}}, tag=!trade_changed] run function skyvoid_additions:mechanics/sandstone_mason_trade/trade_rng
