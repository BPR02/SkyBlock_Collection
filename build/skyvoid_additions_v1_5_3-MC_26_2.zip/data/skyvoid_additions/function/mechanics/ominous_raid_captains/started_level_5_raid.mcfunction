execute store result score @s skyvoid_raid_tracker run time query gametime
scoreboard players add @s skyvoid_raid_tracker 48000
tag @s add skyvoid_additions_started_raid
