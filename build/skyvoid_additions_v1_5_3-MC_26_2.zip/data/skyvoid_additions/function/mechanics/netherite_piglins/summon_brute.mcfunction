tag @s add skyvoid_old
execute summon piglin_brute run function skyvoid_additions:mechanics/netherite_piglins/equip_brute
data merge entity @s {Health: 0.0f, DeathLootTable: "minecraft:empty", DeathTime: 18s, Tags: []}
tp @s ~ -2050 ~
