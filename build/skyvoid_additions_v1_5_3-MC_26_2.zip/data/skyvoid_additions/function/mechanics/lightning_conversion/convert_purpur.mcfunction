setblock ~ ~ ~ air
summon shulker ~ ~-0.5 ~ {active_effects: [{id: "minecraft:resistance", duration: 30, amplifier: 4b, show_particles: 0b}], Color: 16}
