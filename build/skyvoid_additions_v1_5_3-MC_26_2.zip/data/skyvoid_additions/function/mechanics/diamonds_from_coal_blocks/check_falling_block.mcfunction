execute unless entity @s[tag=skyvoid_additions_falling_anvil] if data entity @s {BlockState: {Name: "minecraft:anvil"}} run tag @s add skyvoid_additions_falling_anvil
execute unless entity @s[tag=skyvoid_additions_falling_anvil] if data entity @s {BlockState: {Name: "minecraft:chipped_anvil"}} run tag @s add skyvoid_additions_falling_anvil
execute unless entity @s[tag=skyvoid_additions_falling_anvil] if data entity @s {BlockState: {Name: "minecraft:damaged_anvil"}} run tag @s add skyvoid_additions_falling_anvil
tag @s[tag=!skyvoid_additions_falling_anvil] add skyvoid_additions_anvil_check
execute at @s[tag=skyvoid_additions_falling_anvil] positioned ~ ~-1 ~ as @e[type=item, nbt={Item: {id: "minecraft:coal_block", count: 64}, OnGround: 1b}, nbt=!{Item: {components: {"minecraft:custom_data": {smithed: {ignore: {functionality: 1b}}}}}}, distance=..0.5] run data merge entity @s {Item: {id: "minecraft:diamond", count: 1}}
