execute as @s at @s if block ~ ~ ~ gravel run setblock ~ ~ ~ sand
execute if entity @s[tag=skyvoid_additions_gravel] unless block ~ ~ ~ gravel run kill @s
