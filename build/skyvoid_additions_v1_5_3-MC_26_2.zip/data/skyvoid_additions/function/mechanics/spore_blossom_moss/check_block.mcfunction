execute if block ~ ~-1 ~ air if predicate skyvoid_additions:spore_blossom_moss/spore_blossom_chance run setblock ~ ~-1 ~ spore_blossom
