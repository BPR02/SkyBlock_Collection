tag @s add skyvoid_old
execute summon cave_spider run tp @s @e[type=spider, tag=skyvoid_old, distance=..0.1, limit=1]
data merge entity @s {Health: 0.0f, DeathLootTable: "minecraft:empty", DeathTime: 18s, Tags: []}
tp @s ~ -2050 ~
