execute at @s run loot spawn ~ ~0.8 ~ loot skyvoid_additions:gameplay/gold_block_bartering/bartering
data remove entity @s equipment.offhand
