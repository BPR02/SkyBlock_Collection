# Jump damage logic
function starter:jump_damage

# Apply knockback resistance to players during starter phase
execute if score global starterPhase matches 1 run attribute @a minecraft:generic.knockback_resistance base set 1
execute unless score global starterPhase matches 1 run attribute @a minecraft:generic.knockback_resistance base set 0

# Replace first hostile mob spawn
execute if score global starterPhase matches 1 as @e[type=#minecraft:hostile,tag=!starter_checked,limit=1] run function starter:first_hostile

# End starter phase when the starter zombie is dead
execute if score global starterPhase matches 1 unless entity @e[tag=starter_target] run scoreboard players set global starterPhase 0
