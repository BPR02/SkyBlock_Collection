tag @s add starter_checked

summon zombie ~ ~ ~ {
  Health:1.0f,
  Tags:["starter_target"],
  HandItems:[
    {id:"minecraft:iron_shovel",Count:1b},
    {}
  ],
  HandDropChances:[1.0f,0.0f]
}

kill @s
