# Objectives
scoreboard objectives add jump minecraft.custom:minecraft.jump
scoreboard objectives add starterPhase dummy
scoreboard objectives add mossUnlocked dummy

# Initial values
scoreboard players set global starterPhase 1
scoreboard players set global mossUnlocked 0
