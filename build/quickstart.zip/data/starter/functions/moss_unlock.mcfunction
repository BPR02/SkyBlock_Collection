execute unless score global mossUnlocked matches 1 run scoreboard players set global mossUnlocked 1
