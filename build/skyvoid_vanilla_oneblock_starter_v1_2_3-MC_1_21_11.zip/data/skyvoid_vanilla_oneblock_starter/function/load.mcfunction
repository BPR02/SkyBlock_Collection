scoreboard objectives add skyvoid_vanilla_oneblock dummy
scoreboard objectives add skyvoid_vanilla_oneblock_death deathCount
scoreboard objectives add skyvoid_vanilla_oneblock_food food
scoreboard objectives add skyvoid_vanilla_oneblock_jump minecraft.custom:minecraft.jump
scoreboard players set skyvoid_vanilla_oneblock_starter load.status 1

execute unless score $first_load skyvoid_vanilla_oneblock matches 1 run schedule function skyvoid_vanilla_oneblock_starter:check_disable 10t
scoreboard players set $first_load skyvoid_vanilla_oneblock 1

execute unless score $starter_done skyvoid_vanilla_oneblock matches 1 run schedule function skyvoid_vanilla_oneblock_starter:tick 1t
